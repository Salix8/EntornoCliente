
//Declaración de variables
var URLactual = window.location;
var pathname = window.location.pathname;
var URLProtocol = window.location.protocol;


//Algoritmia

//Visualización
alert(URLactual);
alert(pathname);
alert(URLProtocol);