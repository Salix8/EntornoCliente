
//Declaración de variables

//Algoritmia
function fondo(colores){
    document.body.style.backgroundColor = colores;
}
//Visualización
