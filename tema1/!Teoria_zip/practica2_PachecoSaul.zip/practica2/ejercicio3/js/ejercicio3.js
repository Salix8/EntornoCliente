
//Declaración de variables
//Algoritmia
//Visualización

if (window.confirm( `Navegador` + navigator.appName + `Versión del navegador`)) {
    alert(`continuamos...`);
}


