<?php
    echo $_GET["nombre"] . " recibirás en breve información al correo " . $_GET["correo"];